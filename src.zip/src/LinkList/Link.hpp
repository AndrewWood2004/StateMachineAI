#pragma once

template <typename T>
struct Link
{
    Link<T> *next = nullptr;
    T value;
};
