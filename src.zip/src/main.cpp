#ifdef _WIN32
#include <windows.h>
#endif

#include <iostream>
#include <stdlib.h>

#include <chrono>
#include <vector>

#ifdef __linux__
using namespace std::chrono::_V2;
#elif _WIN32
using namespace std::chrono;
#else
using namespace std::chrono;
#endif

#include "LinkList/LinkList.hpp"
#include "BST/BST.hpp"
#include "UIStateMachine/UIStateMachine.hpp"


void SetIntToSomeThing(int &_num) {
    //if (_num == NULL)
    //    return;
    
    _num = 9808997;
}

void LinkListTest()
{
    LinkList<double> numbers = LinkList<double>();

    numbers.Add(9.0);
    numbers.Add(4.0);
    numbers.Add(7.0);
    numbers.Add(2.0);
    numbers.Add(9.0);

    numbers.Set(4, 8.0);

    numbers.Print();

    for(int i = 1; i < numbers.Count(); i++) {
        std::cout << numbers.Get(i) << " ";
    }

    /*int *arr = calloc(20 * sizeof(int));
    

    std::cout << "Hello, World!" << arr[3] << std::endl;

    int a = 5;
    int b = 10;
    int c = 7;

    if (a < b && c > a) // ||
    {

    }

    while (false)
    {

    }

    for (int i = 0; i < a; i++) {
        //std::cout << "loop " << i << std::endl;
        //printf("loop %d %d %d \n", i, a, b);
    }

    //int* e = new int;
    // *e = 8;
    //delete e;

    void* e;

    e = &b;

    std::cout << b << std::endl;

    SetIntToSomeThing(b);

    std::cout << b << std::endl;*/
}

void LinkListBenchmark() {
    high_resolution_clock::time_point startTime;
    high_resolution_clock::time_point endTime;

    int inputNum = 100;

    startTime = high_resolution_clock::now();

    LinkList<int> linkList = LinkList<int>();

    for (int i = 0; i < inputNum; i++)
    {
        linkList.Add(i);
    }

    endTime = high_resolution_clock::now();

    float deltaTime = duration_cast<nanoseconds>(endTime - startTime).count() / 1000000000.0f;

    std::cout << "build list time: " << deltaTime << std::endl;

    ///////////////////// VECTOR

    startTime = high_resolution_clock::now();

    std::vector<int> vec = {};

    for (int i = 0; i < inputNum; i++)
    {
        vec.push_back(i);
    }

    endTime = high_resolution_clock::now();

    deltaTime = duration_cast<nanoseconds>(endTime - startTime).count() / 1000000000.0f;

    std::cout << "build vector time: " << deltaTime << std::endl;
}

bool IntSort(int a, int b) { return a < b; }

int main(int argc, char* argv[]) {
    UIStateMachine uiStateMachine;
    uiStateMachine.OnCreate();

    // To test AddState:
    uiStateMachine.ChangeState("AddState");
    
    // To test GetState:
    uiStateMachine.ChangeState("GetState");

    // To test SetState:
    uiStateMachine.ChangeState("SetState");

    // To test PrintState:
    uiStateMachine.ChangeState("PrintState");

    // To exit the application:
    uiStateMachine.ChangeState("ExitState");

    return 0; 
}


/*
//LinkListBenchmark();

    BST<int> testTree;

    testTree.Add(20, IntSort);
    testTree.Add(15, IntSort);
    testTree.Add(10, IntSort);
    testTree.Add(10, IntSort);

    for (int i = 0; i < 100; i++)
    {
        testTree.Add(i, IntSort);
    }

    if (testTree.Find(51, IntSort) != nullptr)
    {
        std::cout << "Found" << std::endl;
    }
    else
    {
        std::cout << "!Found" << std::endl;
    }

    //testTree.Print();
    testTree.FreeTree();
*/