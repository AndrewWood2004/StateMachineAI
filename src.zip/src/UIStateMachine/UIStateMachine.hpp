#pragma once
#include "../StateMachine/StateMachine.hpp"
#include "../LinkList/LinkList.hpp"
#include "UIDefaultState.hpp"
#include "AddState.hpp"
#include "SetState.hpp"
#include "GetState.hpp"
#include "PrintState.hpp"
#include "ExitState.hpp"

class UIStateMachine : public StateMachine {
public:
    LinkList<int> list;

    void OnCreate() {
        m_states.push_back(new UIDefaultState(
            "UIDefaultState",
            [this](std::string _name) { this->ChangeState(_name); },
            &list
        ));
        m_states.push_back(new AddState(
            "AddState",
            [this](std::string _name) { this->ChangeState(_name); },
            &list
        ));
        m_states.push_back(new SettingState(
            "SettingState",
            [this](std::string _name) -> void { this->ChangeState(_name); },
            &list
        ));
        m_states.push_back(new GetState(
            "GetState",
            [this](std::string _name) { this->ChangeState(_name); },
            &list
        ));
        m_states.push_back(new PrintState(
            "PrintState",
            [this](std::string _name) { this->ChangeState(_name); },
            &list
        ));
        m_states.push_back(new ExitState(
            "ExitState",
            [this](std::string _name) { this->ChangeState(_name); }
        ));

        ChangeState("UIDefaultState"); // Start with the "UIDefaultState."
    }
};
