#pragma once
#include "../StateMachine/State.hpp"
#include "../LinkList/LinkList.hpp"

class SettingState : public State {
    LinkList<int> *m_list = nullptr;

public:
    SettingState(std::string _name, std::function<void(std::string _name)> _ChangeState, LinkList<int> *_list) :
        State(_name, _ChangeState) {
        m_list = _list;
    }

    void Enter(std::unordered_map<std::string, std::string> &_message) {
        std::cout << "Enter the index where you want to set a value: ";
        int index;
        std::cin >> index;

        if (index < 0 || index >= m_list->Count()) {
            std::cout << "Index out of range." << std::endl;
            ChangeState("UIDefaultState");
            return;
        }

        std::cout << "Enter the value to set: ";
        int value;
        std::cin >> value;

        m_list->Set(index, value);

        std::cout << "Value set at index " << index << " in the list." << std::endl;

        ChangeState("UIDefaultState");
    }

    // Implement the Update and Exit functions if needed.
};
