#pragma once
#include <iostream>

template <typename T>
struct BSTNode {
    T value;
    BSTNode *left = nullptr;
    BSTNode *right = nullptr;
};

template <typename T>
class BST {
private:
    // also called root
    BSTNode<T> *m_head = nullptr;
    int m_size = 0;

    void AddNode(BSTNode<T> *_root, BSTNode<T> *_node, bool (*_func)(T,T))
    {
        if (_func(_node->value, _root->value))
        {
            if (_root->left == nullptr)
            {
                _root->left = _node;
            }
            else {
                AddNode(_root->left, _node, _func);
            }
        }
        else if (_func(_root->value, _node->value))
        {
            if (_root->right == nullptr)
            {
                _root->right = _node;
            }
            else {
                AddNode(_root->right, _node, _func);
            }
        }
        else {
            delete _node;
        }
    }

    void Print(BSTNode<T> *_node)
    {
        if (_node->left != nullptr)
        {
            Print(_node->left);
        }

        std::cout << _node->value << " ";

        if (_node->right != nullptr)
        {
            Print(_node->right);
        }
    }

    void FreeTree(BSTNode<T> *_node)
    {
        if (_node->left != nullptr)
        {
            FreeTree(_node->left);
        }

        if (_node->right != nullptr)
        {
            FreeTree(_node->right);
        }

        delete _node;
    }

    T* Find(T _value, bool (*_func)(T,T), BSTNode<T> *_node) {
        if (_node->value == _value) {
            // use & to get pointer to value
            return &(_node->value);
        }
        else if (_func(_value, _node->value))
        {
            //std::cout << "Left" << std::endl;
            if (_node->left == nullptr){
                return nullptr;
            }else{
                return Find(_value, _func, _node->left);
            }
        }
        else if (_func(_node->value, _value))
        {
            //std::cout << "Right" << std::endl;
            if (_node->right == nullptr){
                return nullptr;
            }else{
                return Find(_value, _func, _node->right);
            }
        }
        else
        {
            //std::cout << "ELSE" << std::endl;
            return nullptr;
        }
    }
public:
void Add(T _value, bool (*_func)(T,T)) {
    BSTNode<T> *node = new BSTNode<T>();
    node->value = _value;

    if (m_head == nullptr)
    {
        m_head = node;
        return;
    }

    AddNode(m_head, node, _func);
}

void Print() {
    std::cout << "print list" << std::endl;
    
    if (m_head != nullptr)
    {
        Print(m_head);
        std::cout << std::endl;
    }
}

void FreeTree()
{
    if (m_head != nullptr)
    {
        FreeTree(m_head);
        m_head = nullptr;
    }
}

T* Find(T _value, bool (*_func)(T,T)) {
    return Find(_value, _func, m_head);
}
};