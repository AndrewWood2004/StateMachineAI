#pragma once
#include <string>
#include <functional>
#include <unordered_map>

class State
{
public:
    std::string name = "";

    std::function<void(std::string _name)> ChangeState = nullptr;

    State (std::string _name, std::function<void(std::string _name)> _ChangeState)
    {
        name = _name;
        ChangeState = _ChangeState; 
    }

    virtual void Enter(std::unordered_map<std::string, std::string> &_message) {}
    virtual void Update(float _deltaTime) {}
    virtual void Exit(std::string _nextStateName) {}
};