#pragma once
#include "State.hpp"
#include <vector>
#include <iostream>

class StateMachine
{
protected:
    std::vector<State*> m_states = {};
    State* m_state = nullptr;

public:
    void OnCreate() {}
    void OnReady() {}

    void OnDestroy()
    {
        for (State *s : m_states)
        {
            delete s;
        }

        m_states.clear();
        m_state = nullptr;
    }

    void OnUpdate(float _dt)
    {
        if (m_state != nullptr)
        {
            m_state->Update(_dt);
        }
    }

    void SetState(State *_state, std::unordered_map<std::string, std::string> &_message)
    {
        if (_state == nullptr)
            return;
        
        if (m_state != nullptr)
        {
            m_state->Exit(_state->name);
        }

        m_state = _state;
        m_state->Enter(_message);
    }

    void ChangeState(std::string _name, std::unordered_map<std::string, std::string> &_message)
    {
        for(State *s : m_states)
        {
            if (s->name == _name)
            {
                SetState(s, _message);
                return;
            }
        }

        std::cout << "State Not Found: " << _name << std::endl;
    }

    void ChangeState(std::string _name)
    {
        std::unordered_map<std::string, std::string> message = {};
        ChangeState(_name, message);
    }
};