#pragma once
#include "../StateMachine/State.hpp"
#include "../LinkList/LinkList.hpp"

class GetState : public State {
    LinkList<int> *m_list = nullptr;

public:
    GetState(std::string _name, std::function<void(std::string _name)> _ChangeState, LinkList<int> *_list) :
        State(_name, _ChangeState) {
        m_list = _list;
    }

    void Enter(std::unordered_map<std::string, std::string> &_message) {
        std::cout << "Enter the index to get a value from the list: ";
        int index;
        std::cin >> index;

        if (index < 0 || index >= m_list->Count()) {
            std::cout << "Index out of range." << std::endl;
            ChangeState("UIDefaultState");
            return;
        }

        int value = m_list->Get(index);

        std::cout << "Value at index " << index << ": " << value << std::endl;

        ChangeState("UIDefaultState");
    }

    // Implement the Update and Exit functions if needed.
};
