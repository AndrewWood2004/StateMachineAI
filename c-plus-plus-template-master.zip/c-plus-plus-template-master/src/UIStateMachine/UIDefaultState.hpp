#pragma once
#include "../StateMachine/State.hpp"
#include "../LinkList/LinkList.hpp"
#include <iostream>

class UIDefaultState : public State {
private:
    LinkList<int> *m_list = nullptr;

public:
    UIDefaultState(std::string _name, std::function<void(std::string _name)> _ChangeState, LinkList<int> *_list)
        : State(_name, _ChangeState), m_list(_list) {}

    void Enter(std::unordered_map<std::string, std::string> &_message) {
        std::cout << "Enter" << std::endl;

        // Prompt the user for an action
        std::cout << "Choose an action:" << std::endl;
        std::cout << "1. Add" << std::endl;
        std::cout << "2. Get" << std::endl;
        std::cout << "3. Set" << std::endl;
        std::cout << "4. Print" << std::endl;
        std::cout << "5. Exit" << std::endl;
        int userChoice;
        std::cout << "Enter your choice: ";
        std::cin >> userChoice;

        switch (userChoice) {
            case 1:
                ChangeState("AddState");
                break;
            case 2:
                ChangeState("GetState");
                break;
            case 3:
                ChangeState("SettingState");
                break;
            case 4:
                ChangeState("PrintState");
                break;
            case 5:
                ChangeState("ExitState");
                break;
            default:
                std::cout << "Invalid choice." << std::endl;
                // You can handle invalid choices as needed.
                break;
        }
    }

    void Update(float _deltaTime) {}
    void Exit(std::string _nextStateName) {
        std::cout << "Exit" << std::endl;
    }
};
