#pragma once
#include "../StateMachine/State.hpp"
#include "../LinkList/LinkList.hpp"
#include <iostream>

class PrintState : public State {
private:
    LinkList<int> *m_list = nullptr;

public:
    PrintState(std::string _name, std::function<void(std::string _name)> _ChangeState, LinkList<int> *_list)
        : State(_name, _ChangeState), m_list(_list) {}

    void Enter(std::unordered_map<std::string, std::string> &_message) {
        std::cout << "Printing..." << std::endl;
        m_list->Print();
        // Change the state back to the default state or any other appropriate state
        ChangeState("UIDefaultState");
    }

    void Update(float _deltaTime) {}
    void Exit(std::string _nextStateName) {
        std::cout << "Exit" << std::endl;
    }
};
