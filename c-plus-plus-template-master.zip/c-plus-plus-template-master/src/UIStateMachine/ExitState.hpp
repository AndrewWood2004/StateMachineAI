#pragma once
#include "../StateMachine/State.hpp"

class ExitState : public State {
public:
    ExitState(std::string _name, std::function<void(std::string _name)> _ChangeState) :
        State(_name, _ChangeState) {
    }

    void Enter(std::unordered_map<std::string, std::string> &_message) {
        std::cout << "Exiting the program..." << std::endl;
        // You can add any additional cleanup or exit logic here as needed.
        exit(0); // Exit the program.
    }

    // Implement the Update and Exit functions if needed.
};
