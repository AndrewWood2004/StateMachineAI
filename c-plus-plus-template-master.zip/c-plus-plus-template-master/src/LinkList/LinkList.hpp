#pragma once
#include "Link.hpp"
#include <iostream>

template <typename T>
class LinkList {
private:
    Link<T> *m_head = nullptr;
    Link<T> *m_end = nullptr;
    unsigned int m_size = 0;

public:
    void Add(T _value)
    {
        m_size++;

        Link<T> *link = new Link<T>();
        (*link).value = _value;

        if (m_head == nullptr)
        {
            m_head = link;
        }
        else
        {
            m_end->next = link;
        }

        m_end = link;
    }

    T Get(unsigned int _index)
    {
        if (_index >= m_size)
        {
            std::cout << "index out of range" << std::endl;
            exit(2);
        }

        Link<T> *current = m_head;
        for (int i = 0; i < _index; i++) {
            current = (*current).next;
        }

        return current->value;
    }

    void Set(unsigned int _index, T _value)
    {
        if (_index >= m_size)
        {
            std::cout << "index out of range" << std::endl;
            exit(2);
        }

        Link<T> *current = m_head;
        for (int i = 0; i < _index; i++) {
            current = (*current).next;
        }

        current->value = _value;
    }

    unsigned int Count() { return m_size; }

    void Print()
    {
        std::cout << "print" << std::endl;
        Link<T> *next = m_head;

        while(next != nullptr) {
            std::cout << (*next).value << std::endl;
            next = next->next;
        }
    }
    //unsigned int Count();
};